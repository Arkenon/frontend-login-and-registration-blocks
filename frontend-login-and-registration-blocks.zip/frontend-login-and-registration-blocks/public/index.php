<?php //Silence is golden
